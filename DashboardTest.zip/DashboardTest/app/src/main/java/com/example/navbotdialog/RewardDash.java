package com.example.navbotdialog;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;


public class RewardDash extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kfc);
    }
}



